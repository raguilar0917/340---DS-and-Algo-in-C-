clang version 12.00
command used to run it:
	 g++ -std=c++11 maxPurchase.cpp -o maxPurchase