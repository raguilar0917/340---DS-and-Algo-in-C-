// CSC340
// Assignment 3.2

#include "TicTacToe.h"

int main() {
   TicTacToe g;
   g.makeMove();
} 
