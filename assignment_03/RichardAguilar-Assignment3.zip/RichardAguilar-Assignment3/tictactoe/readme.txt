To run the code i included a makefile all you have to do is enter the tictactoe directory and it should run with 
entering "make".
I couldn't get the draw option to work sadly i tried multiple ways but could not get it to work.
I also believe i could've improved upon this by using a for loop too check each index for a winner instead of using
many for loops.